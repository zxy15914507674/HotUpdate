﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using MySql.Data.MySqlClient;
using MySql.Data;
using System.Data;
using System.IO;
using System.Xml.Linq;


internal class SQLHelper{

    static string connStr = GetConnStr();

    public bool TestLink() {
        MySqlConnection conn = new MySqlConnection(connStr);
        try
        {
            conn.Open();
            return true;
        }
        catch (System.Exception ex)
        {
            Debug.Log(ex);
            return false;
        }
        finally {
            conn.Close();
        }
        
    }


    public static MySqlDataReader GetReader(string sql) {
        if(connStr==null||connStr.Length==0){
            return null;
        }

        MySqlConnection conn = new MySqlConnection(connStr);
        MySqlCommand cmd = new MySqlCommand(sql, conn);
        MySqlDataReader reader = null;
        try
        {
            conn.Open();
            reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
        catch (System.Exception)
        {
            throw;

        }
        
        return reader;
    }

    /// <summary>
    /// 获取数据库的连接字符串
    /// </summary>
    /// <returns></returns>
    static string GetConnStr() {
        string path = System.Environment.CurrentDirectory + "\\config.xml";
        if (!File.Exists(path)) {
            return "";
        }
        XDocument document = XDocument.Load(path);
            //获取根元素
            XElement root = document.Root;
            //获取ConnectionString节点下的所有元素
            connStr= root.Element("ConnectionString").Value;
           
        return connStr;
    }


}



public class work {
    /***
     * 
     *work 
       id  int 
       workaddress  varchar(200); 
     * 
     */
    public int id;
    public string workaddress;
}

/// <summary>
/// 从数据库获取已经上传的所有实验的名称
/// </summary>
public class GetExperimentNameService {


    /// <summary>
    /// 获取全部的实验名称
    /// </summary>
    /// <returns></returns>
    public List<work> GetExperimentName() {
        List<work> list = new List<work>();
        string sql = "select workaddress from work";
        MySqlDataReader reader = null;

        try
        {
            reader = SQLHelper.GetReader(sql);
            //封装对象
            while(reader.Read()){
                list.Add(new work() {
                    workaddress = reader["workaddress"].ToString()
                });
            }

        }
        catch (System.Exception)
        {

            throw;
        }
        finally { 
            if(reader!=null){
                reader.Close();
            }
        }
        return list;
    }
}

