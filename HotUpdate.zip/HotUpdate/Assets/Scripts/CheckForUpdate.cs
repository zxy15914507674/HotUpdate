﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CheckForUpdate : MonoBehaviour {

    GameObject HotUpdateLogo;
    GameObject UpdateTextMeaage;
    GameObject BtnCheckUpdate;
    bool StartUpdate;
    float RotateSpeed = 8f;


    public ShowInfo showInfo;

    bool SceneReload;         //场景重新加载

    bool ShowMsg;             //显示提升信息
    string Msg;        //提升信息

	void Start () {
        HotUpdateLogo = GameObject.Find("HotUpdateLogo");
        UpdateTextMeaage = GameObject.Find("UpdateTextMeaage");
        BtnCheckUpdate = GameObject.Find("BtnCheckUpdate");
        StartUpdate = false;

        BtnCheckUpdate.GetComponent<Button>().onClick.AddListener(CheckUpdateClick);
        if (GameObject.Find("HotUpdate")!=null)
        {
            GameObject.Find("HotUpdate").transform.SetSiblingIndex(GameObject.Find("HotUpdate").transform.parent.childCount-1);
        }
        

        HotUpdateLogo.SetActive(false);
        UpdateTextMeaage.SetActive(false);

        showInfo += ShowInfomMessage;

        SceneReload = false;
        ShowMsg = false;

	}
	
	// Update is called once per frame
	void Update () {
        if (StartUpdate)
        {
            float z = HotUpdateLogo.transform.localEulerAngles.z - RotateSpeed;
            HotUpdateLogo.transform.localEulerAngles = new Vector3(0f, 0f, z);
        }
        else {
            HotUpdateLogo.SetActive(false);
            UpdateTextMeaage.SetActive(false);
            BtnCheckUpdate.GetComponent<Button>().enabled = true;
        }

        if(SceneReload!=null&&SceneReload&&ShowMsg==false){
            //场景重新加载
            Debug.Log("场景重新加载");

            SceneManager.LoadScene(gameObject.scene.name);
            
            SceneReload = false;
        }

        if(ShowMsg){
            if(Msg!=null&&Msg.Length>0){
                AlertManager.Instance.SetMsg(Msg);
            }
            ShowMsg = false;
        }
	}

    /// <summary>
    /// 检查更新按钮点击事件
    /// </summary>
    private void CheckUpdateClick() {
        HotUpdateLogo.SetActive(true);
        UpdateTextMeaage.SetActive(true);
        StartUpdate = true;
        BtnCheckUpdate.GetComponent<Button>().enabled = false;


        //开启下载场景包线程
        Thread thread = new Thread(DownLoadFile);
        thread.Start();
    }



    /// <summary>
    /// 下载场景包函数
    /// </summary>
    private void DownLoadFile()
    {
        List<string> DownloadFileNameList = new List<string>();
        List<work> list = new GetExperimentNameService().GetExperimentName();
        if (list != null && list.Count > 0)
        {
            foreach (var item in list)
            {
                DownloadFileNameList.Add(item.workaddress);
            }
        }
        
        SceneReload=new HotUpdateHelper().DownLoadFile(DownloadFileNameList,showInfo);

    }

    /// <summary>
    /// 委托回调函数
    /// </summary>
    /// <param name="infoMessage"></param>
    private void ShowInfomMessage(string infoMessage) {
       
        StartUpdate =false;
        ShowMsg = true;
        this.Msg = infoMessage;

        Debug.Log("回调信息:"+infoMessage);
    }
}

/// <summary>
/// 声明委托回调
/// </summary>
/// <param name="infoMessage"></param>

public delegate void ShowInfo(string infoMessage);
