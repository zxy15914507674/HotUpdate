﻿using CompressFile;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Xml;
using System.Xml.Linq;
using UnityEngine;


public class HotUpdateHelper{


    /// <summary>
    /// 检查是否有更新
    /// </summary>
    /// <returns></returns>
    public bool HasFileToDownLoad() {
        List<work> list = new GetExperimentNameService().GetExperimentName();
        List<string> fileNames = new List<string>();
        if(list==null||list.Count==0){
            return false;
        }
        foreach (var item in list)
        {
            fileNames.Add(item.workaddress);
        }
        List<string> NotDownLoad = GetFileNameNotDownLoad(fileNames);
        if(NotDownLoad==null||NotDownLoad.Count==0){
            return false;
        }
        return true;
    }



    /// <summary>
    /// 根据文件名称集合下载文件
    /// </summary>
    /// <param name="fileNames">文件名称集合</param>
    /// <param name="info">下载信息更新回UI的委托</param>
    /// <param name="dic">key为下载的文件名，value为场景类型(1:化学 2：物理  3:生物)</param>
    /// <returns></returns>
    public bool DownLoadFile(List<string> fileNames, ShowInfo info, Dictionary<string, string> dic)
    {

        List<string> NotDownLoad = GetFileNameNotDownLoad(fileNames);

        if (NotDownLoad == null || NotDownLoad.Count == 0 || dic == null)
        {
            info("没有资源可以更新");
            return false;
        }

        foreach (var fileName in NotDownLoad)
        {
            try
            {
                DownLoadFile(fileName,dic);
            }
            catch (System.Exception)
            {
                info("更新失败!");
                throw;
            }
        }
        Debug.Log("全部下载完毕");
        info("更新完毕");
        return true;
    }


    /// <summary>
    /// 下载单独的文件
    /// </summary>
    /// <param name="fileName"></param>
    /// <param name="dic">key为下载的文件名，value为场景类型(1:化学 2：物理  3:生物)</param>
    /// <returns></returns>
    private bool DownLoadFile(string fileName, Dictionary<string, string> dic)
    {
        string url = ReadDownLoadUrlRootFromXML() + fileName;
        Debug.Log(url);
        string DesPath = System.Environment.CurrentDirectory+"\\"+fileName;

        //如果当前下载的压缩包在本地存在，则进行删除

        if (File.Exists(DesPath))
        {
            File.Delete(DesPath);
        }


        Debug.Log(DesPath);
        //指定http下载地址
        HttpWebRequest resquest = (HttpWebRequest)WebRequest.Create(url);
        //指定欺骗服务器下载地址
        //resquest.Referer = Cheaturl;
        try
        {
             //复制下载流,并写入文件
        using (HttpWebResponse response = (HttpWebResponse)resquest.GetResponse())
        {
            if (response.StatusCode == HttpStatusCode.OK)
            {
                using (Stream stream = response.GetResponseStream())
                {
                    using (Stream fsStream = new FileStream(DesPath, FileMode.Create))
                    {

                        byte[] buffer = new byte[1024 * 1024];
                        while (true)
                        {
                            int read = stream.Read(buffer, 0, buffer.Length);
                            if (read <= 0) break;
                            fsStream.Write(buffer, 0, read);
                        }
                    }
                }

                Debug.Log(fileName+"下载完毕!!");
                //进行解压和放入指定的目录
                DecompressionFile(fileName,dic[fileName]);
                return true;
            }

            else
            {
                Debug.Log("下载失败" + response.StatusCode);
                return false;
            }
        }
        }
        catch (System.Exception ex)
        {
            Debug.Log(ex);
            Debug.Log("下载"+fileName+"失败!");
            throw;
        }
        
       
    }

    /// <summary>
    /// 获取那些文件还没有进行下载
    /// </summary>
    /// <param name="fileNames">文件名称集合</param>
    /// <returns></returns>
    private List<string> GetFileNameNotDownLoad(List<string> fileNames) {
        List<string> listHasDownLoad=ReadHasDownLoadFromXML();
        List<string> listUnDownLoad = new List<string>();
        foreach (var fileName in fileNames)
        {
            if(!listHasDownLoad.Contains(fileName)){
                listUnDownLoad.Add(fileName);
            }
        }
        return listUnDownLoad;
    }



    /// <summary>
    /// 从xml配置文件中获取文件下载的根路径
    /// </summary>
    /// <returns></returns>
    private string ReadDownLoadUrlRootFromXML() {
        string path = System.Environment.CurrentDirectory + "\\config.xml";

        if (!File.Exists(path))
        {
            return null;
        }
        XDocument document = XDocument.Load(path);
        //获取根元素
        XElement root = document.Root;
        //获取DownLoadUrl节点下的元素
        XElement url = root.Element("DownLoadUrl");
       
        return url.Value;
    }

    /// <summary>
    /// 从配置文件中读取已经下载的文件名称
    /// </summary>
    /// <returns></returns>
    private List<string> ReadHasDownLoadFromXML() {
        string path = System.Environment.CurrentDirectory + "\\config.xml";

        List<string> fileNamesList = new List<string>();
        if (!File.Exists(path))
        {
            return null;
        }
        XDocument document = XDocument.Load(path);
        //获取根元素
        XElement root = document.Root;

        if (root.Element("fileNames")==null)
        {
            XElement fileNames = new XElement("fileNames");
            root.Add(fileNames);
            document.Save(path);
        }


        if (root.Element("SceneType") == null)
        {
            XElement SceneType = new XElement("SceneType");
            root.Add(SceneType);
            document.Save(path);
        }



        //获取fileNames节点下的所有元素
        IEnumerable<XElement> indxs = root.Element("fileNames").Elements();
        foreach (XElement item in indxs)
        {
            fileNamesList.Add(item.Value);
        }
        
        return fileNamesList;
    }


    /// <summary>
    /// 将文件名写入配置文件
    /// </summary>
    /// <param name="fileName">文件名</param>
    /// <param name="SceneName">要写入的场景名称</param>
    /// <param name="SceneType">要写入的场景类型</param>
    /// <returns></returns>
    private bool WriteFileNameToXML(string fileName,string SceneName,string SceneType) {

        string path = System.Environment.CurrentDirectory + "\\config.xml";
        if (!File.Exists(path))
        {
            return false;
        }

        XDocument document = XDocument.Load(path);
        //获取根元素
        XElement root = document.Root;

        XElement fileNamesEle=root.Element("fileNames");

        XElement fileNameEle = new XElement("fileName");
        fileNameEle.Value = fileName;
        fileNamesEle.Add(fileNameEle);


        if (root.Element("SceneType")==null)
        {
            XElement SceneTypeEle = new XElement("SceneType");
            root.Add(SceneTypeEle);
            document.Save(path);
        }
        XElement SceneTypeEles = root.Element("SceneType");

        if (SceneTypeEles.Element("Chemistry") == null)
        {
            XElement ChemistryEle = new XElement("Chemistry");
            SceneTypeEles.Add(ChemistryEle);
            document.Save(path);
        }


        if (SceneTypeEles.Element("Physics") == null)
        {
            XElement PhysicsEle = new XElement("Physics");
            SceneTypeEles.Add(PhysicsEle);
            document.Save(path);
        }

        if (SceneTypeEles.Element("Biology") == null)
        {
            XElement BiologyEle = new XElement("Biology");
            SceneTypeEles.Add(BiologyEle);
            document.Save(path);
        }



       if(SceneType=="1"){
           IEnumerable<XElement> xlesChemistry = SceneTypeEles.Element("Chemistry").Elements("SceneName");
           if(xlesChemistry!=null){
               foreach (var itemChemistry in xlesChemistry)
               {
                   if(itemChemistry.Value==SceneName){
                       document.Save(path);
                       return false;
                   }
               }
           }

           XElement SceneNameOfChemistry= new XElement("SceneName");
           SceneNameOfChemistry.Value = SceneName;
           SceneTypeEles.Element("Chemistry").Add(SceneNameOfChemistry);
       }
       else if (SceneType == "2")
       {
           IEnumerable<XElement> xlesPhysics = SceneTypeEles.Element("Physics").Elements("SceneName");
           if (xlesPhysics != null)
           {
               foreach (var itemPhysics in xlesPhysics)
               {
                   if (itemPhysics.Value == SceneName)
                   {
                       document.Save(path);
                       return false;
                   }
               }
           }

           XElement SceneNameOfPhysics = new XElement("SceneName");
           SceneNameOfPhysics.Value = SceneName;
           SceneTypeEles.Element("Physics").Add(SceneNameOfPhysics);
       }

       else if (SceneType == "3")
       {

           IEnumerable<XElement> xlesBiology = SceneTypeEles.Element("Biology").Elements("SceneName");
           if (xlesBiology != null)
           {
               foreach (var itemBiology in xlesBiology)
               {
                   if (itemBiology.Value == SceneName)
                   {
                       document.Save(path);
                       return false;
                   }
               }
           }
           XElement SceneNameOfBiology = new XElement("SceneName");
           SceneNameOfBiology.Value = SceneName;
           SceneTypeEles.Element("Biology").Add(SceneNameOfBiology);
       }


        


        document.Save(path);

        return true;
    
    }



    string ResourcesDir = System.Environment.CurrentDirectory + "\\" + "SceneResources";
    string XmlDir = System.Environment.CurrentDirectory + "\\" + "SceneResources\\XML";
    string ScriptDir = System.Environment.CurrentDirectory + "\\" + "SceneResources\\Scripts";

    //其它资源文件目录
    string OtherResorucesDir = System.Environment.CurrentDirectory + "\\" + "SceneResources\\OtherResoruces\\";
    string CurrentOtherResorucesDir;


    //解压后的文件路径
    string DecompressDir = System.Environment.CurrentDirectory + "\\";

    /// <summary>
    /// 根据文件名称解压文件
    /// </summary>
    /// <param name="fileName">文件名称</param>
    ///  <param name="SceneType">场景的类型</param>
    /// <returns></returns>
    public bool DecompressionFile(string fileName,string SceneType) {
        if(!Directory.Exists(ResourcesDir)){
            Directory.CreateDirectory(ResourcesDir);
        }

        if (!Directory.Exists(XmlDir))
        {
            Directory.CreateDirectory(XmlDir);
        }
        if (!Directory.Exists(ScriptDir))
        {
            Directory.CreateDirectory(ScriptDir);
        }
        string FilePath = System.Environment.CurrentDirectory + "\\" + fileName;
        Debug.Log(FilePath);


        //进行解压文件
        string fileNameDes=fileName.Split('.')[0];
        string extractPath =fileNameDes;

        string  CurrentDecompressDir=DecompressDir+extractPath;

        //如果加压前存在与解压后的文件夹相同，则删除文件夹和里面的文件
        if (Directory.Exists(CurrentDecompressDir))
        {
            DirectoryInfo subdir = new DirectoryInfo(CurrentDecompressDir);
            subdir.Delete(true);          //删除目录和文件

        }

        
        new ZipHelper().UnZip(FilePath, extractPath);

        //解压完毕，把原来的压缩文件进行删除
        if(File.Exists(FilePath)){
            File.Delete(FilePath);
        }

        MoveTheFileToDir(CurrentDecompressDir,fileName,SceneType);
        return false;
    }


    private bool MoveTheFileToDir(string CurrentDecompressDir, string fileName, string SceneType)
    {

        if (!Directory.Exists(ResourcesDir))
        {
            Directory.CreateDirectory(ResourcesDir);
        }

        if (!Directory.Exists(XmlDir))
        {
            Directory.CreateDirectory(XmlDir);
        }

        if (!Directory.Exists(ScriptDir))
        {
            Directory.CreateDirectory(ScriptDir);
        }



        if (!Directory.Exists(CurrentDecompressDir))
        {
            return false;
        }
        if (Directory.GetDirectories(CurrentDecompressDir) == null)
        {
            return false;
        }

        //获取该文件夹里面的第一个文件夹(因为就只有一个文件夹)
        string FileDir = Directory.GetDirectories(CurrentDecompressDir)[0];
        //获取该文件夹内的所有文件
        string[] fileNames = Directory.GetFiles(FileDir);

        //保存场景名称
        string SceneName=null;
        //生成对应的场景其它资源的文件夹
        foreach (var item in fileNames)
        {
            if(item.Contains(".zxy")){
                string[] str = item.Split('\\','.');
                if(str!=null){
                    SceneName = str[str.Length - 2];
                    CurrentOtherResorucesDir = OtherResorucesDir + SceneName;
                    Debug.Log("CurrentOtherResorucesDir:" + CurrentOtherResorucesDir);
                    if (!Directory.Exists(CurrentOtherResorucesDir))
                    {
                        Directory.CreateDirectory(CurrentOtherResorucesDir);
                    }
                }
                
            }
        }




        foreach (var nameitem in fileNames)
        {
            string []str = nameitem.Split('\\');
            string name=str[str.Length-1];
            if(name.Contains(".script")){
               
                string ScriptDesName = ScriptDir +"\\"+ name;
                File.Copy(nameitem, ScriptDesName, true);
            }
            else if(name.Contains(".zxy")){
                
                string ZxyDesName = ResourcesDir + "\\" + name;
                File.Copy(nameitem, ZxyDesName, true);     
            }
            else if (name.Contains(".xml"))
            {


                string XmlDesName = XmlDir + "\\" + name;
                File.Copy(nameitem, XmlDesName, true);
            }
            //其它相关的资源文件放在对应的场景目录下
            else { 
                if(Directory.Exists(CurrentOtherResorucesDir)){
                    string ResorucesDesName = CurrentOtherResorucesDir + "\\" + name;
                    File.Copy(nameitem, ResorucesDesName, true);
                }
            }
        }
        //复制文件后，把解压后的文件和文件夹删除
        if (Directory.Exists(CurrentDecompressDir))
        {
            DirectoryInfo subdir = new DirectoryInfo(CurrentDecompressDir);
            subdir.Delete(true);          //删除目录和文件

        }

        //把当前下载的文件名写入配置文件
        WriteFileNameToXML(fileName,SceneName,SceneType);

        return true;
    }
    


}
